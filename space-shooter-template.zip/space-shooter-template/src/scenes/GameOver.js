import Phaser from '../lib/phaser.js'

export default class GameOver extends Phaser.Scene{
    constructor()
	{
        super('game-over')
    }

    preload()
    {
       
    }
    
    create(){
       
    }
}