import Phaser from '../lib/phaser.js'

export default class Enemy extends Phaser.Physics.Arcade.Sprite{

    constructor(scene, x, y, texture)
    {
       
    }
    spawn(){
                   
    }
    die(){
       
    }
    update(time){ 
        
    }
}

