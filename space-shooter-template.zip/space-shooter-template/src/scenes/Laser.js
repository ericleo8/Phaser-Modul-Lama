import Phaser from '../lib/phaser.js'

export default class Laser extends Phaser.Physics.Arcade.Sprite{
    constructor(scene, x, y, texture){
        
    }

    fire (x,y){
        
    }

    die(){
       
    }

    update(time){
       
    }
}
