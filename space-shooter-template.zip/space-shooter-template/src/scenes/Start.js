import Phaser from '../lib/phaser.js'

export default class Start extends Phaser.Scene{

    constructor()
	{
		super('start')
    }
    
    preload()
    {
       
    }

    create()
    {
        
    }
    

}
