import Phaser from '../lib/phaser.js'
import Laser from './Laser.js'
import Enemy from './Enemy.js'

export default class Game extends Phaser.Scene{
    constructor(){
      super('shooter-space')
    }
    init(){
        
    }
    preload(){
        
    }
    create(){
      
    }
    update(){
      
    }
}

