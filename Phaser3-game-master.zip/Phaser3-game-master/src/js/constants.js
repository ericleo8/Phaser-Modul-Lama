const info = {
    gameText: {
        '1': 'Eat more food to jump higher!',
        '2': 'Jumping more will reduces your Energy faster!',
        '3': 'Complete your Training exercises to get more Food!',
        '4': 'You will get Trophy only when your Energy is more than 500!'
    }
}

export default info;