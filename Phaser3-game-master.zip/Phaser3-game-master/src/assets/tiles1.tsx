<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="tiles.png" width="280" height="280"/>
</tileset>
