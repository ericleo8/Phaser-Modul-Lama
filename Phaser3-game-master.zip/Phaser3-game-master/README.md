# Phaser3-Game
A simple HTML5 game development using Phaser 3 with ES6.

### Demo:
https://phaser3.herokuapp.com/

## Installation
npm install

### Run the Project in development
npm run build

npm run start


